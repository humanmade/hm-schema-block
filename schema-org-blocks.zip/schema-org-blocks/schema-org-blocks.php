<?php
/**
 * Plugin Name: Schema.org Blocks
 * Description: Extend all blocks with schema.org type mapping and structured data output
 * Version: dev-918eb0a
 * Author: Human Made
 * Author URI: https://humanmade.com
 * Text Domain: schema-org-blocks
 * Requires at least: 6.9
 * Requires PHP: 8.0
 *
 * @package SchemaOrgBlocks
 */

namespace SchemaOrgBlocks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SCHEMA_ORG_BLOCKS_PATH', __DIR__ );
define( 'SCHEMA_ORG_BLOCKS_URL', plugins_url( '', __FILE__ ) );
define( 'SCHEMA_ORG_BLOCKS_VERSION', 'dev-918eb0a' );

// Require Composer autoloader.
if ( file_exists( __DIR__ . '/vendor/autoload.php' ) ) {
	require_once __DIR__ . '/vendor/autoload.php';
}

require_once __DIR__ . '/inc/namespace.php';
require_once __DIR__ . '/inc/schema-types.php';
require_once __DIR__ . '/inc/block-values.php';
require_once __DIR__ . '/inc/dynamic-values.php';
require_once __DIR__ . '/inc/block-extensions.php';
require_once __DIR__ . '/inc/schema-output.php';
require_once __DIR__ . '/inc/patterns.php';

// Bootstrap the plugin.
bootstrap();
